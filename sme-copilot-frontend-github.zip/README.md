# SME Copilot Frontend (React + Vite + Tailwind)

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

This is the frontend for SME Copilot.

## Local Development
```bash
npm install
npm run dev
```

## Environment Variables
- `VITE_API_BASE` - Backend API URL
